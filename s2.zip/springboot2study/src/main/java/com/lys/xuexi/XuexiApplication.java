package com.lys.xuexi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XuexiApplication {

    public static void main(String[] args) {
        SpringApplication.run(XuexiApplication.class, args);
    }

}

